Scriptname Component extends Form Native Hidden


; F4SE additions built 2026-08-16 18:45:49.250000 UTC
MiscObject Function GetScrapItem() native

Function SetScrapItem(MiscObject akMisc) native

GlobalVariable Function GetScrapScalar() native

Function SetScrapScalar(GlobalVariable akGlobal) native