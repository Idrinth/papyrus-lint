Scriptname BoSResQuestScript extends Quest
