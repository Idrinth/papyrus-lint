Scriptname COMMacCreadyScript extends Quest Conditional
