Scriptname BOSR05Script extends MinRecruitQuestScript Conditional

