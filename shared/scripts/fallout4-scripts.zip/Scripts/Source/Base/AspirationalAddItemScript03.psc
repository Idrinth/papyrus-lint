Scriptname AspirationalAddItemScript03 extends ObjectReference Conditional

