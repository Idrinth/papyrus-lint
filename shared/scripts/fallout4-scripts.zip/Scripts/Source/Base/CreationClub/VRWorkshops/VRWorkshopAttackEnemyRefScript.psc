Scriptname CreationClub:VRWorkshops:VRWorkshopAttackEnemyRefScript extends RefCollectionAlias
{Handles events and visual effects for VR Workshop enemy attacks}

Group EffectShaders
	EffectShader Property TeleportInFXS Auto Const Mandatory
	EffectShader Property TeleportOutFXS Auto Const Mandatory
	EffectShader Property HologramShaunFXS Auto Const Mandatory
EndGroup

Group SoundEffects
	Sound Property TeleportSound Auto Const Mandatory
EndGroup

Group QuestData
	Quest Property VRAttackQuest Auto Const Mandatory
	{The VR Attack quest so we can stop it when all hostiles are cleared}
	RefCollectionAlias Property AttackEnemiesRefCol Auto Const Mandatory
	{Collection of enemies spawned during staged VR Attack}
	Int Property StageHostilesCleared = 50 Auto Const
	{Stage to set when player/settlers kill all of the spawned enemies, to finish objective}
	Int Property ObjectiveComplete = 0 Auto Const
	{The objective to show/hide for spawned enemies}
EndGroup

Float AnimationDuration = 1.3 Const

Event OnLoad(ObjectReference akSender)
	debug.trace("VR WORKSHOPS: VR enemy loaded")
	BlockActivation(True,True) ;prevent pickpocket or looting after dead
EndEvent

Event OnDying(ObjectReference akSender, Actor akKiller)
	debug.trace("VR WORKSHOPS: VR enemy killed")
	;Teleport out
	TeleportOutFXS.play(akSender, AnimationDuration)
	TeleportSound.Play(akSender)
	Utility.Wait(AnimationDuration) ;wait for effect to finish
	akSender.Disable() ;make the body disappear
	RemoveEnemyFromRefCollection(akSender) ;"Call home" to remove self from ref collection, do this last to block cannibal perk
EndEvent

Function RemoveEnemyFromRefCollection(ObjectReference enemyToRemove)
	debug.trace("VR WORKSHOP: Removing " + enemyToRemove + "from RefCollection.")

	AttackEnemiesRefCol.RemoveRef(enemyToRemove)

	;This is the last enemy in the collection, finish the quest
	If(!AttackEnemiesRefCol.GetCount())
		debug.trace("VR WORKSHOPS: There are no more enemies in the ref collection, complete objective and stop quest")
		VRAttackQuest.SetObjectiveCompleted(ObjectiveComplete)
		VRAttackQuest.Stop()
	EndIf

EndFunction