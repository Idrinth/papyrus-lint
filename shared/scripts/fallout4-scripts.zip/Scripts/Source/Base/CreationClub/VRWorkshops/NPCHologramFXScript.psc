Scriptname CreationClub:VRWorkshops:NPCHologramFXScript extends activemagiceffect
{Used to play FX on spawned-in enemies in VR Attack Mode}

Group EffectShaders
	EffectShader Property TeleportInFXS Auto Const Mandatory
	EffectShader Property TeleportOutFXS Auto Const Mandatory
	EffectShader Property HologramShaunFXS Auto Const Mandatory
EndGroup

Group SoundEffects
	Sound Property TeleportSound Auto Const Mandatory
EndGroup

Float AnimationDuration = 1.2;

Event OnEffectStart(Actor akTarget, Actor akCaster)
	;Teleport in effects
	TeleportInFXS.play(akTarget, AnimationDuration)
	TeleportSound.Play(akTarget)
	Utility.Wait(AnimationDuration)
	;Hologram effects
	HologramShaunFXS.Play(akTarget)
	akTarget.SetAlpha(0.50)
EndEvent