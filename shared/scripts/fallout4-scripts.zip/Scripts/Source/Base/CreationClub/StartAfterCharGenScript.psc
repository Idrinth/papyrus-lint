Scriptname CreationClub:StartAfterCharGenScript extends Quest

Int Property MyStageToSet Auto Const Mandatory

Quest Property MQ102 Auto Const Mandatory
Int Property CharGenStageToWatch = 10 Auto Const
Int CCCharGenTimer = 10

Event OnInit()
	if MQ102.GetStageDone(CharGenStageToWatch)
		StartTimer(5, CCCharGenTimer)
		GotoState("WaitingToStart")
	else
		RegisterForRemoteEvent(MQ102, "OnStageSet")
	endif
EndEvent

Event Quest.OnStageSet(quest akSendingQuest, int CharGenStage, int StageItem)
	if CharGenStage == CharGenStageToWatch
		if GetStageDone(MyStageToSet) == false
			SetCreationStage()
		endif
	endif
EndEvent

State WaitingToStart
	Event OnTimer(int aiTimerID)
		if aiTimerID == CCCharGenTimer
			if GetStageDone(MyStageToSet) == false
				SetCreationStage()
			endif
		endif
	EndEvent
EndState

Function SetCreationStage()
	SetStage(MyStageToSet)
EndFunction