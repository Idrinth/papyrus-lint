Scriptname Flora extends Activator Hidden


; SKSE64 additions built 2026-08-27 15:31:27.926000 UTC
SoundDescriptor Function GetHarvestSound() native
Function SetHarvestSound(SoundDescriptor akSoundDescriptor) native

Form Function GetIngredient() native
Function SetIngredient(Form akIngredient) native