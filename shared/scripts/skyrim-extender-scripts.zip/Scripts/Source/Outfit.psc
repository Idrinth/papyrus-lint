Scriptname Outfit extends Form Hidden


; SKSE64 additions built 2026-08-27 15:31:27.926000 UTC

int Function GetNumParts() native
Form Function GetNthPart(int n) native