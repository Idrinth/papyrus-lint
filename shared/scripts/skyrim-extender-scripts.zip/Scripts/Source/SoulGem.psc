Scriptname SoulGem extends MiscObject Hidden

; SKSE64 additions built 2026-08-27 15:31:27.926000 UTC

int Function GetSoulSize() native
int Function GetGemSize() native