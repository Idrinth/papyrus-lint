Scriptname Book Extends Form Hidden

; SKSE64 additions built 2026-08-27 15:31:27.926000 UTC
; Returns the spell that this book teaches
Spell Function GetSpell() native
Int Function GetSkill() native
bool Function IsRead() native
bool Function IsTakeable() native