Scriptname CWMainGateExteriorScript extends ReferenceAlias  
