;BEGIN FRAGMENT CODE - Do not edit anything between this and the end comment
;NEXT FRAGMENT INDEX 1
Scriptname BYOH_TIF__01003DEA Extends TopicInfo Hidden

;BEGIN FRAGMENT Fragment_0
Function Fragment_0(ObjectReference akSpeakerRef)
Actor akSpeaker = akSpeakerRef as Actor
;BEGIN CODE
;Initial house will be in Hjaalmarch...
(GetOwningQuest() as BYOHRelationshipAdoptableOrphanageSc).StoreHouseLocation(7)
;END CODE
EndFunction
;END FRAGMENT

;END FRAGMENT CODE - Do not edit anything between this and the begin comment

Quest Property RelationshipAdoptableOrphanage  Auto  

ReferenceAlias Property Aventus  Auto  

ReferenceAlias Property Samuel  Auto  

ReferenceAlias Property Runa  Auto  

ReferenceAlias Property Francois  Auto  

ReferenceAlias Property Hroar  Auto  
